// PoemFerry shared corpus — public-domain poems in their original languages.
// Every text here is pre-1928 / clearly public domain. Poems are NEVER translated;
// only `note` (the match explanation) is written in the querying user's language (Chinese here).

export const QUERY = "深秋黄昏的乡愁";

export const CORPUS_SIZE = 384102; // total poems "read" by the host

export const POEMS = [
  {
    id: "zh-tianjingsha",
    title: "天净沙·秋思",
    author: "马致远",
    year: "约 1300",
    lang: { code: "zh", name: "汉语" },
    cjk: true,
    text: "枯藤老树昏鸦，\n小桥流水人家，\n古道西风瘦马。\n夕阳西下，\n断肠人在天涯。",
    evidence: [0, 3, 4],
    tags: ["秋思", "昏鸦", "夕阳", "天涯", "断肠"],
    note: "整首以秋日黄昏的枯败意象堆叠，末句「断肠人在天涯」正是漂泊在外的乡愁。",
    score: 0.97,
    source: { name: "中国哲学书电子化计划", url: "https://ctext.org" },
    license: "Public Domain"
  },
  {
    id: "ja-basho-karaeda",
    title: "枯枝に烏",
    author: "松尾芭蕉",
    year: "1680",
    lang: { code: "ja", name: "日语" },
    cjk: true,
    text: "枯枝に烏の\nとまりけり\n秋の暮",
    evidence: [0, 2],
    tags: ["秋の暮", "烏", "枯枝"],
    note: "「秋の暮」即深秋黄昏，枯枝上独栖的乌鸦与你描述的画面几乎重合。",
    score: 0.94,
    source: { name: "Aozora Bunko 青空文庫", url: "https://www.aozora.gr.jp" },
    license: "Public Domain"
  },
  {
    id: "fr-verlaine-automne",
    title: "Chanson d'automne",
    author: "Paul Verlaine",
    year: "1866",
    lang: { code: "fr", name: "法语" },
    cjk: false,
    text: "Les sanglots longs\nDes violons\nDe l'automne\nBlessent mon cœur\nD'une langueur\nMonotone.\n\nTout suffocant\nEt blême, quand\nSonne l'heure,\nJe me souviens\nDes jours anciens\nEt je pleure;",
    evidence: [2, 9, 10, 11],
    tags: ["automne", "souvenir", "langueur", "pleure"],
    note: "「秋」的呜咽让人「想起旧日而流泪」——旋律化的怀旧与乡愁，语气与你的描述吻合。",
    score: 0.91,
    source: { name: "Wikisource (fr)", url: "https://fr.wikisource.org" },
    license: "Public Domain"
  },
  {
    id: "de-rilke-herbsttag",
    title: "Herbsttag",
    author: "Rainer Maria Rilke",
    year: "1902",
    lang: { code: "de", name: "德语" },
    cjk: false,
    text: "Herr: es ist Zeit. Der Sommer war sehr groß.\nLeg deinen Schatten auf die Sonnenuhren,\nund auf den Fluren laß die Winde los.\n\nWer jetzt kein Haus hat, baut sich keines mehr.\nWer jetzt allein ist, wird es lange bleiben,\nwird wachen, lesen, lange Briefe schreiben\nund wird in den Alleen hin und her\nunruhig wandern, wenn die Blätter treiben.",
    evidence: [3, 4, 7],
    tags: ["Herbst", "allein", "kein Haus", "wandern"],
    note: "秋日里「谁此刻没有房子，就不必再建」——无家、独行、落叶，是乡愁的另一副面孔。",
    score: 0.88,
    source: { name: "Project Gutenberg", url: "https://www.gutenberg.org" },
    license: "Public Domain"
  },
  {
    id: "zh-jingyesi",
    title: "静夜思",
    author: "李白",
    year: "约 725",
    lang: { code: "zh", name: "汉语" },
    cjk: true,
    text: "床前明月光，\n疑是地上霜。\n举头望明月，\n低头思故乡。",
    evidence: [3],
    tags: ["明月", "思故乡", "霜"],
    note: "最直白的乡愁范本：「低头思故乡」。虽非黄昏而是夜，但乡愁的内核一致。",
    score: 0.85,
    source: { name: "中国哲学书电子化计划", url: "https://ctext.org" },
    license: "Public Domain"
  },
  {
    id: "es-becquer-rima53",
    title: "Rima LIII",
    author: "Gustavo Adolfo Bécquer",
    year: "1871",
    lang: { code: "es", name: "西班牙语" },
    cjk: false,
    text: "Volverán las oscuras golondrinas\nen tu balcón sus nidos a colgar,\ny otra vez con el ala a sus cristales\njugando llamarán;\n\npero aquellas que el vuelo refrenaban\ntu hermosura y mi dicha al contemplar,\naquellas que aprendieron nuestros nombres,\nésas... ¡no volverán!",
    evidence: [0, 7],
    tags: ["golondrinas", "volverán", "nostalgia"],
    note: "归燕会再来，但「那些……不会再回来了」——对逝去时光不可复返的怀念。",
    score: 0.82,
    source: { name: "Wikisource (es)", url: "https://es.wikisource.org" },
    license: "Public Domain"
  },
  {
    id: "zh-chunjiang",
    title: "春江花月夜",
    author: "张若虚",
    year: "约 720",
    lang: { code: "zh", name: "汉语" },
    cjk: true,
    text: "春江潮水连海平，海上明月共潮生。\n滟滟随波千万里，何处春江无月明！\n江流宛转绕芳甸，月照花林皆似霰。\n空里流霜不觉飞，汀上白沙看不见。\n江天一色无纤尘，皎皎空中孤月轮。\n江畔何人初见月？江月何年初照人？\n人生代代无穷已，江月年年望相似。\n不知江月待何人，但见长江送流水。\n白云一片去悠悠，青枫浦上不胜愁。\n谁家今夜扁舟子？何处相思明月楼？\n可怜楼上月徘徊，应照离人妆镜台。\n玉户帘中卷不去，捣衣砧上拂还来。\n此时相望不相闻，愿逐月华流照君。\n鸿雁长飞光不度，鱼龙潜跃水成文。\n昨夜闲潭梦落花，可怜春半不还家。\n江水流春去欲尽，江潭落月复西斜。\n斜月沉沉藏海雾，碣石潇湘无限路。\n不知乘月几人归，落月摇情满江树。",
    evidence: [8, 9, 14],
    tags: ["相思", "明月", "不还家", "江月", "离人"],
    note: "整首写春夜江畔的月色与离思——「青枫浦上不胜愁」「何处相思明月楼」「可怜春半不还家」，正是游子思归的乡愁。以此长诗测试折叠/展开排版。",
    score: 0.79,
    source: { name: "中国哲学书电子化计划", url: "https://ctext.org" },
    license: "Public Domain"
  },
  {
    id: "en-dickinson-slant",
    title: "There's a certain Slant of light",
    author: "Emily Dickinson",
    year: "约 1861",
    lang: { code: "en", name: "英语" },
    cjk: false,
    text: "There's a certain Slant of light,\nWinter Afternoons –\nThat oppresses, like the Heft\nOf Cathedral Tunes –\n\nHeavenly Hurt, it gives us –\nWe can find no scar,\nBut internal difference –\nWhere the Meanings, are –",
    evidence: [0, 1, 6],
    tags: ["slant of light", "afternoon", "internal"],
    note: "冬日午后斜斜的光带来无形的压抑——与「黄昏时分的心绪」同调的意象。",
    score: 0.71,
    source: { name: "Project Gutenberg", url: "https://www.gutenberg.org" },
    license: "Public Domain"
  }
];

// A pool of poem fragments (real PD lines) used to animate the "reading" swarm —
// bits of text flit past as agents scan the library.
export const SCAN_FRAGMENTS = [
  "枯藤老树昏鸦", "秋の暮", "Les sanglots longs", "Der Sommer war sehr groß",
  "低头思故乡", "Volverán las oscuras golondrinas", "Winter Afternoons",
  "夕阳西下", "Blessent mon cœur", "unruhig wandern", "疑是地上霜",
  "とまりけり", "D'une langueur", "kein Haus hat", "internal difference",
  "断肠人在天涯", "Je me souviens", "die Blätter treiben", "小桥流水人家",
  "golondrinas", "Cathedral Tunes", "古道西风瘦马", "秋思", "l'automne",
  "明月光", "Heavenly Hurt", "sus nidos a colgar", "Et je pleure",
  "望明月", "die letzte Süße", "烏のとまり", "oscuras", "langueur monotone"
];

// Languages present in the library, for the scanning readout.
export const LANGS = [
  { code: "zh", name: "汉语", n: 71204 },
  { code: "en", name: "English", n: 138890 },
  { code: "fr", name: "français", n: 41220 },
  { code: "de", name: "Deutsch", n: 39510 },
  { code: "ja", name: "日本語", n: 28744 },
  { code: "es", name: "español", n: 33112 },
  { code: "it", name: "italiano", n: 18402 },
  { code: "la", name: "latina", n: 13020 }
];

export const SUGGESTIONS = [
  "深秋黄昏的乡愁",
  "哭了之后喝酒",
  "在天愿作比翼鸟",
  "a candle burning in an empty room",
  "海が終わるところ"
];

// Retrieval "personas"
export const MODES = [
  { key: "hybrid", name: "混合", desc: "语义 + 字面，默认" },
  { key: "semantic", name: "语义", desc: "按意象与主旨跨语言匹配" },
  { key: "keyword", name: "字面 / 概念", desc: "跨语言近义桥接 河→río→川" },
  { key: "deep", name: "深扫", desc: "逐首读全文，读到满意即停" }
];
