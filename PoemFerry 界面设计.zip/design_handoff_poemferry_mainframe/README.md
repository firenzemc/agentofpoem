# Handoff: PoemFerry / 诗渡 — Mainframe 检索界面

## Overview
PoemFerry（诗渡）是一个**跨语言的公共领域诗歌语义搜索引擎**。用户用任意语言、以最模糊的方式描述一首记不清的诗（一个画面、一种情绪、半句残句），系统调度一群 AI agent 在数十万首诗里逐首审读，找出命中的诗，**以原文（绝不翻译）**呈现，并解释它为何对上用户的描述。

核心体验意图：**模糊进，精确出**；让"从一团模糊收敛到一首确切的诗"这个过程**可被感知**——意图被解析、候选被打捞、蜂群 agent 并发审读、命中的诗逐张涌现。气质是"冷静仪器感（主机房/实验室）× 古典诗意"的并置。

本交接包对应的是 **Mainframe（主机房）** 这一版界面方向——控制台式多区布局，用户最终选定的方案。

## About the Design Files
本包内的文件是**用 HTML 编写的设计参考**——展示预期外观与交互行为的高保真原型，**不是可直接拷贝上线的生产代码**。它们用一套自研的轻量组件运行时（`.dc.html` + `support.js`）编写，仅用于原型演示。

你的任务是**在目标代码库的既有技术环境中重建这些 HTML 设计**（React / Vue / Svelte / SwiftUI / 原生等），沿用该代码库已确立的组件模式、状态管理与样式方案。若项目尚无前端环境，请为其选择最合适的框架再实现。请把设计文件当作"外观 + 行为的事实来源"，而非要照搬的代码结构。

真实后端应通过 **SSE（Server-Sent Events）流式**推送检索过程事件（意图解析 → 候选数 → 已读计数/命中 → 逐张诗卡），前端据此驱动下述动效与状态机。原型里的时间线（`T_PARSE` / `T_DREDGE` / `T_READ`）是模拟值，实现时应由真实事件流替代。

## Fidelity
**High-fidelity (hifi)**。颜色、字体、间距、动效、交互均为最终意图，请按下文的 token 与规格**像素级重建**，同时用目标代码库既有的组件库落地。

## 布局总览
桌面为三栏控制台网格；窄屏（`< 940px`）降级为单栏堆叠。

- 顶栏 header：高 52px，左 logo「诗渡 / POEMFERRY」+ 副标题，右侧状态灯 + 计时器。
- Body 三栏：`grid-template-columns: 232px 1fr 288px`。
  - **左栏 Telemetry（遥测）**：全库规模、已通读进度条、候选/强命中计数、语种分布条、停止条件。
  - **中栏 Stage（舞台）**：idle 态为搜索输入；running/done 态为 query 回显 + 4 段 pipeline + 点阵画布 + 意图 chips + 结果诗卡流。
  - **右栏 Agent Swarm（蜂群）**：一列 agent，逐行滚动显示各自正在读的残句 + 已读计数 + 命中 ✓。
- 窄屏：左右栏在 idle 隐藏，running 时堆叠到内容下方；中栏输入区改为单列。

## 状态机（核心）
`phase ∈ { idle, parse, dredge, read, done }`

- **idle**：Hero 文案 + 单一搜索框 + 引导示例 chips + 检索人格选择。
- **parse（解析意图）**：约 1.3s。展示"解析意图"高亮，pipeline 第 1 段激活。
- **dredge（打捞候选）**：约 1.5s。候选数从 0 缓动升到 `CAND_TARGET`（原型 12,880）。点阵中候选点微亮。
- **read（通读审读）**：约 4.4s。已读数缓动升到 `READ_TARGET`（原型 3,418）；点阵星点**零散地陆续点亮**（并行蜂群，非扫描线）；命中的诗卡按匹配度顺序**逐张涌现**，对应点阵上的点亮成金色带环。
- **done（呈现原典）**：定格所有计数；显示**停止条件**文案（深扫模式：收益递减，读满 N 首后主动停止；其它模式：按相关度取前 N 首）。

缓动统一用 `ease(t) = 1 - (1-t)^3`（ease-out cubic）。

## 检索人格（Retrieval Mode）
四选一，默认 `hybrid`；原型演示用 `deep`：
- `hybrid` 混合：语义 + 字面，默认。
- `semantic` 语义：按意象与主旨跨语言匹配。
- `keyword` 字面 / 概念：跨语言近义桥接（河→río→Fluss→川）。
- `deep` 深扫：逐首读全文、读到满意即停，实时显示"已读 N / 共 M、强命中 K、因何停止"。**深扫必须诚实显示停止原因与已读比例**——"读到一半停了"不可被误读成"库里没有"。

## 组件与规格

### Header（52px 高，左对齐 gap 18px，`padding: 0 22px`）
- 「诗渡」`Noto Serif SC` 500 / 20px / letter-spacing 2px / 色 `#EDE4D3`。
- 「POEMFERRY」`IBM Plex Mono` / 11px / letter-spacing .14em / 色 `#5EE6C4`。
- 副标题 `IBM Plex Mono` 10.5px `#56607a`：`跨语言 · 公共领域 · 语义检索主机`。
- 右侧状态：7px 圆点（带 `box-shadow: 0 0 8px 当前色`）+ 文案；计时器 `IBM Plex Mono` `#56607a`，格式 `X.XXs`。
- 状态色映射：idle/done = `#5EE6C4`（薄荷）；parse/dredge/read = `#E8B15E`（琥珀）。文案：`待命 READY` / `解析中 PARSING` / `打捞中 DREDGING` / `通读中 READING` / `完成 SETTLED`。
- 背景 `rgba(9,12,19,.7)` + `backdrop-filter: blur(8px)`；下边框 `1px solid rgba(255,255,255,.07)`。

### 搜索输入（idle 态，中栏，`max-width: 720px` 居中）
- 引导语 `IBM Plex Mono` 11px `#5EE6C4`：`让机器一目十行，替你把整座图书馆读一遍。`
- H1 `Noto Serif SC` 500 / 34px / line-height 1.4：`你记得一首诗的碎片，/ 却找不到它。`色 `#EDE4D3`。
- 说明段 14px `#8a94a6`，「原文」二字 `#EDE4D3`。
- 输入框容器：`rgba(255,255,255,.03)` 背景，`1px solid rgba(94,230,196,.3)` 边框，圆角 10px，`padding: 12px 16px`，`box-shadow: 0 0 40px rgba(94,230,196,.06)`；左侧 `›` 提示符 `#5EE6C4`。
- input 文本 `Noto Serif SC` 17px `#EDE4D3`；placeholder `描述那首你记不清的诗……`。
- 提交按钮：背景 `#5EE6C4`、文字 `#06110d`、圆角 6px、`padding: 9px 18px`、`IBM Plex Mono` 12px 600，文案 `检索 ⏎`。回车亦提交。
- 引导示例 chips（圆角 20px、`1px solid rgba(255,255,255,.08)`、`Noto Serif SC` 13px `#a7b0c0`，hover 边框 `rgba(94,230,196,.5)`）：`深秋黄昏的乡愁` / `哭了之后喝酒` / `在天愿作比翼鸟` / `a candle burning in an empty room` / `海が終わるところ`。
- 检索人格卡：选中态背景 `rgba(94,230,196,.07)`、边框 `rgba(94,230,196,.4)`、名称色 `#5EE6C4`；未选边框 `rgba(255,255,255,.08)`、名称 `#c7cedb`。名称 `IBM Plex Sans` 13px 600，描述 `IBM Plex Mono` 9.5px `#56607a`。

### Pipeline（running 态，4 段等宽，外框圆角 8px）
段：`01 解析意图` / `02 打捞候选` / `03 通读审核` / `04 呈现原典`。每段含序号（激活 `#5EE6C4`）、中文标签、子信息（当前候选数/已读数/命中数）。激活段背景 `rgba(94,230,196,.07)`、底部 `2px solid #5EE6C4`；已完成段文字 `#8a94a6`；未来段 `#56607a`。段间竖分隔 `1px solid rgba(255,255,255,.07)`。

### 全库点阵画布（`<canvas>`，高 210px，圆角 8px，背景 `#080b12`，边框 `1px solid rgba(255,255,255,.07)`）
**这是承载"规模感 + 被通读感 + 收敛"的核心视觉，务必忠实实现。**
- 生成 `N = min(2400, floor(canvasWidth * 5))` 个点，随机散布。约 13% 标记为"候选点"（`cand`）。
- 从候选点里随机挑 **每首真实结果诗一个**"命中点"，记 `poemIdx = 0..结果数-1`（即命中点与真实诗卡一一对应）。
- 每个候选点有自己的 `igniteAt ∈ [0,1)` 点亮时刻。
- **绘制逻辑（每帧 requestAnimationFrame）**：
  - `readP` = read 阶段进度 0→1。
  - 候选点：当 `readP >= igniteAt`（或 done）时置 `lit=true` 并给一次 `flash=1`（渐衰）——效果是星点**零散陆续点亮**（并行蜂群覆盖，**不是扫描线**）。已点亮点色 `rgba(94,230,196, 0.5~0.85)`，半径 1.4~2.5px（flash 时更大更亮）。
  - 未点亮候选点：`rgba(94,230,196,0.30)`，半径 1.15px。
  - 背景未读星点：`rgba(140,152,175, 0.09~0.14)`（微弱闪烁），半径 0.9px。
  - **命中点**（当 `poemIdx < 已涌现诗卡数` 时激活）：金色 `rgba(232,177,94, pulse)`（`pulse = 0.62 + 0.38*sin(t/300 + poemIdx)`），半径 2.4px，外加一圈**呼吸金环**（半径约 5.5 + 1.5*sin）。**命中就地点亮，不做物理聚拢**——收敛靠"全灭→候选微亮→通读点亮→命中结环"的状态语言 + 漏斗数字，因此命中 2 首或 200 首都成立。
- **可交互（重要，不可省略——否则点阵沦为装饰）**：
  - 鼠标悬停最近的"已点亮/命中"点（命中半径 11px 内）：显示 tooltip。命中点 → `◈ {标题} · {语言} — 点击查看`（边框琥珀 `rgba(232,177,94,.5)`、文字 `#F3D9A6`），光标 `pointer`；普通已读点 → `已通读 · 「{残句}」`（边框薄荷 `rgba(94,230,196,.35)`、文字 `#c7cedb`），光标 `crosshair`。悬停点加白色描边高亮。
  - 点击命中点 → **滚动到对应诗卡并高亮**（诗卡以 `data-poem="pf-{index}"` 标识；高亮用一次 `box-shadow` 脉冲 ~1.1s）。
  - tooltip 定位在点上方（`translate(-50%,-160%)`），`rgba(8,11,17,.94)` 背景 + `backdrop-filter: blur(3px)`，`IBM Plex Mono` 10.5px。
- 画布左上角常驻标签：`全库 384,102 · 亮＝已通读 · 金环＝命中·可点击`（`IBM Plex Mono` 9px）；右下角 `并行通读中… / 打捞候选… / 通读完成 / 解析中…`（`#5EE6C4`）。

### 意图 chips（parse 之后出现）
`意图解析 →` 后跟若干跨语言概念桥接 chip，如：`深秋 · autumn · 秋 · Herbst · l'automne` / `黄昏 · dusk · 暮 · crépuscule · afternoon` / `乡愁 · homesick · nostalgia · 郷愁 · Heimweh`。chip 背景 `rgba(94,230,196,.08)`、边框 `rgba(94,230,196,.22)`、圆角 5px；概念头 `Noto Serif SC` `#5EE6C4`，展开词 `IBM Plex Mono` 9.5px `#8a94a6`。

### 结果诗卡（逐张 `animation: pf-rise .5s`，`gap: 16px`）
每张卡（`data-poem="pf-{i}"`）：
- 边框 `1px solid rgba(255,255,255,.09)`，圆角 10px，背景 `linear-gradient(180deg, rgba(20,26,35,.9), rgba(14,18,26,.9))`。
- 头部：排名 `#01` `IBM Plex Mono` `#5EE6C4`；标题 `Noto Serif SC` 500 / 19px `#EDE4D3`；作者 `IBM Plex Sans` 12px `#a7b0c0`；元信息 `{年代} · {语言}` `IBM Plex Mono` 10px `#56607a`；右侧匹配度百分比 `#E8B15E` 14px + 标签「匹配度」。
- **诗体（全文，仅原始语言，绝不翻译，保留原始换行）**：
  - CJK 诗：`Noto Serif SC / Noto Serif JP` 17px / line-height 1.9 / letter-spacing .04em / 色 `#d9d2c2`。
  - 拉丁文诗：`Noto Serif` 15px / line-height 1.75 / 色 `#d9d2c2`。
  - **证据行高亮**（诗中真正对上描述的那几句）：文字色 `#F3D9A6`，背景 `linear-gradient(90deg, rgba(232,177,94,.14), rgba(232,177,94,.02))`，左边框 `2px solid #E8B15E`。
- **长诗折叠**：超过 6 行默认只显示前 6 行；展开按钮 `IBM Plex Mono` 10.5px `#5EE6C4`。**展开且超过 16 行（长诗）时，诗体进入定高滚动面板**：`max-height: 340px; overflow-y: auto`，配 `mask-image: linear-gradient(180deg, transparent 0, #000 22px, #000 calc(100% - 22px), transparent 100%)` 上下渐隐——保证《长恨歌》这类长诗不撑爆版面。折叠按钮文案含"面板内滚动"提示。
- **匹配说明**（用**用户查询的语言**写的一句话解释）：块背景 `rgba(94,230,196,.05)`、左边框 `2px solid rgba(94,230,196,.4)`；前缀 `为何命中 · ` `#5EE6C4`，正文 `IBM Plex Sans` 12.5px `#c7cedb`。
- **匹配标签**（用**诗自身的语言**写的关键词，如西语诗挂西语词）：`#{词}`，背景 `rgba(255,255,255,.04)`、边框 `rgba(255,255,255,.07)`、圆角 4px、11px `#8a94a6`；CJK 标签用 `Noto Serif SC`，拉丁用 `Noto Serif`。
- **来源出处 + 版权许可**（一等信息，可点击溯源）：右对齐，6px 薄荷圆点 + `{来源名} · {许可} ↗`，`IBM Plex Mono` 10px `#56607a`，hover `#5EE6C4`，`target="_blank"`。
- done 态尾注：`— 通读完毕 · 诗永不翻译，以上皆为原文原排 —`。

### 左栏 Telemetry（遥测）
- 标题 `TELEMETRY / 遥测`（`IBM Plex Mono` 9.5px `#56607a`）。
- 全库：`384,102` `#EDE4D3` + `首诗 · 8 种语言 · 34 处语料`。
- 已通读：大数 `#5EE6C4` + 进度条（`linear-gradient(90deg,#5EE6C4,#E8B15E)`）+ `/ {候选} 待读候选`。
- 候选打捞 / 强命中：两个大数（后者 `#E8B15E`）。
- 语种分布条：每语种一行（名称 + 条 + `Nk`）；汉语条用实心薄荷 `#5EE6C4`，其余 `rgba(94,230,196,.4)`。
- **停止条件**（done 态）：标题 `#E8B15E` + 文案 `IBM Plex Mono` 10.5px `#8a94a6`。

### 右栏 Agent Swarm（蜂群）
- 标题 `AGENT SWARM` + 状态（运行时 `15 并行`、done `待命`）。
- **说明行**（重要设计决定）：`每个 agent 并行掠读不同的诗 · 右列为已读数 · ✓ 为标记命中`。
- **agent 不绑定固定语言**——每行显示：状态圆点（活跃薄荷 / 命中瞬间琥珀 / 空闲灰）、agent 编号 `A01…`、**此刻正读的残句（混合语言、快速滚动）**、右侧已读计数、命中时闪现的 `✓`（琥珀）。原型 15 个 agent，每 ~120ms 刷新一次残句并累加读数，随机 6% 概率闪 ✓。
  - 说明：真实系统里每个 agent 都在飞快掠过不同语言的诗，所以**刻意不设 zh/la/it 之类的固定语言标签**——那会误导。残句字体按语言自适应（CJK 用 `Noto Serif SC`，其余 `IBM Plex Mono`）。

## 动画与过渡
- `pf-rise`：`opacity 0→1, translateY(14px)→0`，0.4~0.6s ease——诗卡、意图 chips、尾注入场。
- `pf-blink`：光标闪烁。
- 点阵：`requestAnimationFrame` 逐帧；**注意后台标签页 rAF 会暂停，属正常**。
- 计数缓动：ease-out cubic，`tick` 每 55ms 一次（原型；实现时改由 SSE 事件驱动）。
- agent 刷新：每 ~120ms。

## 状态变量（原型所用，供参考）
`phase, query, mode, read, cand, hits, revealed, stopReason, elapsed, agents[], foldOpen{}, tip`。
- `revealed`：已涌现的诗卡数，同时驱动点阵命中点的激活。
- `foldOpen{poemId: bool}`：每首诗的展开状态。
- `tip`：点阵 tooltip（`{x, y, text, hit}`）。
- agent 项：`{ id, frag, readN, active, flash }`（**无 lang 字段**）。

## Design Tokens
颜色：
- 背景：`#070910`（页面）、`#080b12`（画布）、`#0a0d14`（卡片底）。
- 主强调（薄荷 / 机器）：`#5EE6C4`。
- 次强调（琥珀 / 命中·诗意）：`#E8B15E`，命中文字 `#F3D9A6`。
- 诗体正文：`#d9d2c2`；标题 `#EDE4D3`。
- 文本层级：主 `#e8ecf2` / `#c7cedb`，次 `#8a94a6`，弱 `#56607a`，最弱 `#3a4152`。
- 分隔线：`rgba(255,255,255,.06~.09)`。

字体：
- `IBM Plex Sans`（UI 无衬线，正文/按钮/说明）。
- `IBM Plex Mono`（数据、计时、标签、agent 残句拉丁文——仪器感）。
- `Noto Serif SC`（中文诗体 + 标题「诗渡」）、`Noto Serif JP`（日文含假名）、`Noto Serif`（拉丁文诗体）。
- 通过 Google Fonts 引入，字重 400/500/600。

圆角：4px（标签）/ 5~6px（chip、按钮）/ 8px（画布、pipeline、人格卡）/ 10px（诗卡）。
间距基准：诗卡间 16px；栏内块 14~18px。

## 硬性产品原则（影响实现）
1. **诗永不翻译**：法语诗原文呈现给中文用户；解释（匹配说明）用用户语言，诗体本身保持原样、保留原始换行。
2. **每首诗必带来源与许可**，可点击溯源（公共领域合规，一等信息）。
3. **前端自包含 + SSE 流式**：检索过程需可流式渲染、无外部运行时依赖。
4. **深扫必须诚实**：显示停止原因与已读比例，不能让"读到收益递减而停"被误读成"库里没有"。
5. **多语言排版**：需同时优雅处理 CJK（中/日）与带变音符号的法/德/西/意/英——行高、字距、混排都要照顾。

## Assets
无位图/图标资源依赖。所有图形（点阵、进度条、圆点、金环）均为 `<canvas>` 或 CSS 绘制。字体来自 Google Fonts。语料数据见 `poems.js`（含每首诗的标题/作者/年代/语言、原文、证据行索引、匹配标签、匹配说明、匹配度、来源与许可）——真实实现应替换为后端接口返回的等价结构。

## Files（本包内）
- `PoemFerry-1a-Mainframe.dc.html` — 最终选定的 Mainframe 界面（完整原型：模板 + 逻辑）。
- `poems.js` — 语料 + 常量（`POEMS`、`SCAN_FRAGMENTS`、`LANGS`、`SUGGESTIONS`、`MODES`、`CORPUS_SIZE`）。数据结构可作为后端返回契约的参考。
- `support.js` — 原型用的轻量组件运行时（**仅供本地打开原型预览**，不需迁移到目标代码库）。
- 其余方向（1b 观星台 / 1c 文字之渡 / 1d 分拣台）未包含——如需其视觉参考可另行索取。

## 如何本地预览原型
用浏览器打开 `PoemFerry-1a-Mainframe.dc.html` 即可（三个 `.dc.html/poems.js/support.js` 需在同一目录）。点「检索」观察完整流式过程；点阵动画在标签页处于前台时运行。
